package myapp.is.com.todo;


import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

//Here We are creating the DataBase(SQLite) of the Room.

@Database(entities = {ListEntity.class},version = 1)
public abstract class ListDatabase extends RoomDatabase {
    private static ListDatabase instance;    //We create it because we want to make single instance of the class which is
                                             // used by our whole app.
                                             //we can not make more than one instance that is why it is called singalton.
    public abstract ListDAO ListDAO();

    public static synchronized ListDatabase getInstance(Context context){
        if(instance==null){       //Here we are creating instance of database if databse instance is null.
            instance= Room.databaseBuilder(context.getApplicationContext(),
                    ListDatabase.class,"list_database")
                    .fallbackToDestructiveMigration()  //this will help if we change the version no. .
                    .build();
        }
        return instance;
    }




}
