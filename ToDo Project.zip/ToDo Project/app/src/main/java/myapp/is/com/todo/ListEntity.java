package myapp.is.com.todo;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

//Here We are creating the Entity Part of the Room.

@Entity(tableName = "Reminder_table")
   public class ListEntity {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;

    private String description;


    public ListEntity(String title, String description, int priority) {
        this.title = title;
        this.description = description;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

}
