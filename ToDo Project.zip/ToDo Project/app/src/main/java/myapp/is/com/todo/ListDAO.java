package myapp.is.com.todo;

import java.util.List;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

//Here We are creating the DAO part of the ROOM.

@Dao
public interface ListDAO {

    @Insert
    void insert(ListEntity listEntity);

    @Update
    void update(ListEntity listEntity);

    @Delete
    void delete(ListEntity listEntity);

    @Query("DELETE  FROM Reminder_table")
    void deleteAllReminder();

    @Query("SELECT * FROM Reminder_table ")
    LiveData<List<ListEntity>> getAllNotes();  //LiveData<> is used because if any change happens then our List<Note> will update Automatically.
}
